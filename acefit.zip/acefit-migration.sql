-- ============================================================
-- AceFit – Complete Supabase Migration
-- VERSION: 2.0  (single file – paste full content into
--               Supabase → SQL Editor → Run)
-- ============================================================

-- ── Extensions ──────────────────────────────────────────────
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- ============================================================
-- 1. PROFILES
-- ============================================================
CREATE TABLE IF NOT EXISTS profiles (
  id              UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email           TEXT,
  name            TEXT,
  phone           TEXT,
  avatar_url      TEXT,
  default_address TEXT,
  default_state   TEXT,
  total_spent     NUMERIC DEFAULT 0,
  total_orders    INTEGER DEFAULT 0,
  created_at      TIMESTAMPTZ DEFAULT NOW(),
  updated_at      TIMESTAMPTZ DEFAULT NOW()
);

-- Auto-create profile on every new sign-up
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
BEGIN
  INSERT INTO public.profiles (id, email)
  VALUES (NEW.id, NEW.email)
  ON CONFLICT (id) DO NOTHING;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- ============================================================
-- 2. PRODUCTS
-- ============================================================
CREATE TABLE IF NOT EXISTS products (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name            TEXT NOT NULL,
  description     TEXT,
  price           NUMERIC NOT NULL CHECK (price >= 0),
  original_price  NUMERIC CHECK (original_price >= 0),
  category        TEXT NOT NULL DEFAULT 'tshirts'
                  CHECK (category IN ('tshirts','joggers','hoodies','shorts','leggings','sports-bra','tank-tops','tracksuits','accessories')),
  gender          TEXT DEFAULT 'unisex'
                  CHECK (gender IN ('men','women','unisex')),
  sizes           TEXT[] DEFAULT ARRAY['S','M','L','XL'],
  image_url       TEXT,
  stock           INTEGER DEFAULT 0 CHECK (stock >= 0),
  rating          NUMERIC DEFAULT 4.5 CHECK (rating BETWEEN 0 AND 5),
  is_new          BOOLEAN DEFAULT false,
  is_bestseller   BOOLEAN DEFAULT false,
  is_active       BOOLEAN DEFAULT true,
  created_at      TIMESTAMPTZ DEFAULT NOW(),
  updated_at      TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- 3. ORDERS  (full delivery + tracking fields)
-- ============================================================
CREATE TABLE IF NOT EXISTS orders (
  id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id             UUID REFERENCES profiles(id) ON DELETE SET NULL,

  -- Customer
  customer_name       TEXT NOT NULL,
  customer_email      TEXT NOT NULL,
  customer_phone      TEXT NOT NULL,

  -- Delivery
  delivery_address    TEXT NOT NULL,
  delivery_landmark   TEXT,
  delivery_state      TEXT,
  delivery_lga        TEXT,
  delivery_fee        NUMERIC DEFAULT 0,
  delivery_zone       TEXT,
  estimated_delivery  TEXT,

  -- Items & payment
  items               JSONB NOT NULL DEFAULT '[]',
  subtotal            NUMERIC NOT NULL DEFAULT 0,
  total               NUMERIC NOT NULL DEFAULT 0,

  -- Order lifecycle
  status              TEXT DEFAULT 'pending'
                      CHECK (status IN ('pending','processing','shipped','delivered','cancelled')),
  status_history      JSONB DEFAULT '[]',   -- array of {status, timestamp, note}

  -- Payment
  payment_method      TEXT DEFAULT 'opay'
                      CHECK (payment_method IN ('opay','whatsapp','bank_transfer')),
  payment_status      TEXT DEFAULT 'unpaid'
                      CHECK (payment_status IN ('unpaid','paid','failed','refunded')),
  payment_reference   TEXT,

  notes               TEXT,
  admin_notes         TEXT,
  created_at          TIMESTAMPTZ DEFAULT NOW(),
  updated_at          TIMESTAMPTZ DEFAULT NOW()
);

-- Trigger: append to status_history whenever status changes
CREATE OR REPLACE FUNCTION public.log_order_status_change()
RETURNS TRIGGER
LANGUAGE plpgsql AS $$
BEGIN
  IF NEW.status IS DISTINCT FROM OLD.status THEN
    NEW.status_history = COALESCE(OLD.status_history, '[]'::jsonb) ||
      jsonb_build_object(
        'status', NEW.status,
        'timestamp', NOW(),
        'previous', OLD.status
      );
    NEW.updated_at = NOW();
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS order_status_change ON orders;
CREATE TRIGGER order_status_change
  BEFORE UPDATE ON orders
  FOR EACH ROW EXECUTE FUNCTION public.log_order_status_change();

-- Trigger: update profile totals when order is delivered
CREATE OR REPLACE FUNCTION public.update_profile_on_delivery()
RETURNS TRIGGER
LANGUAGE plpgsql AS $$
BEGIN
  IF NEW.status = 'delivered' AND OLD.status != 'delivered' AND NEW.user_id IS NOT NULL THEN
    UPDATE profiles
    SET total_spent  = total_spent  + NEW.total,
        total_orders = total_orders + 1,
        updated_at   = NOW()
    WHERE id = NEW.user_id;
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS order_delivered_update_profile ON orders;
CREATE TRIGGER order_delivered_update_profile
  AFTER UPDATE ON orders
  FOR EACH ROW EXECUTE FUNCTION public.update_profile_on_delivery();

-- ============================================================
-- 4. SUPPORT TICKETS
-- ============================================================
CREATE TABLE IF NOT EXISTS support_tickets (
  id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id       UUID REFERENCES profiles(id) ON DELETE SET NULL,
  name          TEXT NOT NULL,
  email         TEXT NOT NULL,
  phone         TEXT,
  message       TEXT NOT NULL,
  status        TEXT DEFAULT 'open'
                CHECK (status IN ('open','in-progress','resolved','closed')),
  reply         TEXT,
  admin_notes   TEXT,
  created_at    TIMESTAMPTZ DEFAULT NOW(),
  updated_at    TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- 5. FEEDBACK / REVIEWS
-- ============================================================
CREATE TABLE IF NOT EXISTS feedback (
  id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id       UUID REFERENCES profiles(id) ON DELETE SET NULL,
  name          TEXT NOT NULL,
  email         TEXT NOT NULL,
  rating        INTEGER NOT NULL CHECK (rating BETWEEN 1 AND 5),
  message       TEXT NOT NULL,
  is_published  BOOLEAN DEFAULT true,
  created_at    TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- 6. WISHLIST
-- ============================================================
CREATE TABLE IF NOT EXISTS wishlists (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id     UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  product_id  UUID NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  created_at  TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(user_id, product_id)
);

-- ============================================================
-- 7. EMAIL NOTIFICATION LOG  (track sent emails)
-- ============================================================
CREATE TABLE IF NOT EXISTS email_logs (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  to_email    TEXT NOT NULL,
  subject     TEXT NOT NULL,
  type        TEXT,   -- 'welcome' | 'otp' | 'order_confirm' | 'order_status' | 'ticket' etc.
  ref_id      UUID,   -- order_id or ticket_id
  status      TEXT DEFAULT 'sent',
  created_at  TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- 8. ROW LEVEL SECURITY (RLS)
-- ============================================================

-- ── profiles ────────────────────────────────────────────────
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Users view own profile"   ON profiles;
DROP POLICY IF EXISTS "Users update own profile" ON profiles;
CREATE POLICY "Users view own profile"   ON profiles FOR SELECT USING (auth.uid() = id);
CREATE POLICY "Users update own profile" ON profiles FOR UPDATE USING (auth.uid() = id);

-- ── products ────────────────────────────────────────────────
ALTER TABLE products ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Public product read"    ON products;
DROP POLICY IF EXISTS "Service role manages"   ON products;
CREATE POLICY "Public product read"  ON products FOR SELECT USING (is_active = true);
CREATE POLICY "Service role manages" ON products FOR ALL  USING (auth.role() = 'service_role');

-- ── orders ──────────────────────────────────────────────────
ALTER TABLE orders ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Users view own orders"  ON orders;
DROP POLICY IF EXISTS "Anyone can create order" ON orders;
DROP POLICY IF EXISTS "Service role order mgmt" ON orders;
CREATE POLICY "Users view own orders"   ON orders FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Anyone can create order" ON orders FOR INSERT WITH CHECK (true);
CREATE POLICY "Service role order mgmt" ON orders FOR ALL   USING (auth.role() = 'service_role');

-- ── support_tickets ─────────────────────────────────────────
ALTER TABLE support_tickets ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Anyone create ticket"      ON support_tickets;
DROP POLICY IF EXISTS "Users view own tickets"    ON support_tickets;
DROP POLICY IF EXISTS "Service role ticket mgmt"  ON support_tickets;
CREATE POLICY "Anyone create ticket"     ON support_tickets FOR INSERT WITH CHECK (true);
CREATE POLICY "Users view own tickets"   ON support_tickets FOR SELECT USING (auth.uid() = user_id OR auth.role() = 'service_role');
CREATE POLICY "Service role ticket mgmt" ON support_tickets FOR ALL    USING (auth.role() = 'service_role');

-- ── feedback ────────────────────────────────────────────────
ALTER TABLE feedback ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Anyone submit feedback"  ON feedback;
DROP POLICY IF EXISTS "Published feedback read" ON feedback;
CREATE POLICY "Anyone submit feedback"  ON feedback FOR INSERT WITH CHECK (true);
CREATE POLICY "Published feedback read" ON feedback FOR SELECT USING (is_published = true);

-- ── wishlists ────────────────────────────────────────────────
ALTER TABLE wishlists ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Users own wishlist" ON wishlists;
CREATE POLICY "Users own wishlist" ON wishlists FOR ALL USING (auth.uid() = user_id);

-- ── email_logs ───────────────────────────────────────────────
ALTER TABLE email_logs ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Service role email logs" ON email_logs;
CREATE POLICY "Service role email logs" ON email_logs FOR ALL USING (auth.role() = 'service_role');

-- ============================================================
-- 9. STORAGE BUCKET  (run separately if needed)
-- ============================================================
-- NOTE: You can also create this from Supabase Dashboard → Storage
-- INSERT INTO storage.buckets (id, name, public)
-- VALUES ('product-images', 'product-images', true)
-- ON CONFLICT DO NOTHING;
--
-- DROP POLICY IF EXISTS "Public read product images" ON storage.objects;
-- DROP POLICY IF EXISTS "Service upload product images" ON storage.objects;
-- CREATE POLICY "Public read product images"    ON storage.objects FOR SELECT USING (bucket_id = 'product-images');
-- CREATE POLICY "Service upload product images" ON storage.objects FOR INSERT USING (bucket_id = 'product-images');

-- ============================================================
-- 10. ADMIN ACCOUNT SETUP
-- ============================================================
-- IMPORTANT: After running this migration, create the admin
-- account by going to:
--   Supabase Dashboard → Authentication → Users → Add user
--   Email: Acefitandgainz@gmail.com
--   Password: AceFit@Admin2025!
--   (or any strong password of your choice)
--
-- Then add the admin row in profiles manually:
-- INSERT INTO profiles (id, email, name)
-- SELECT id, email, 'AceFit Admin'
-- FROM auth.users
-- WHERE email = 'Acefitandgainz@gmail.com'
-- ON CONFLICT (id) DO UPDATE SET name = 'AceFit Admin';

-- ============================================================
-- 11. SEED DEMO PRODUCTS
-- ============================================================
INSERT INTO products (name, description, price, original_price, category, gender, sizes, image_url, stock, rating, is_new, is_bestseller, is_active)
VALUES
  (
    'AceFit Pro Performance Tee',
    'Moisture-wicking performance tee engineered for intense workouts. Ultra-breathable fabric with 4-way stretch for maximum range of motion.',
    8500, 12000, 'tshirts', 'men',
    ARRAY['S','M','L','XL','XXL'],
    'https://i.imgur.com/YmQ8fjQ.png',
    15, 4.9, true, true, true
  ),
  (
    'AceFit Power Joggers',
    'Lightweight tapered joggers with zip pockets and elastic drawstring waistband. Perfect for training or casual streetwear.',
    15000, NULL, 'joggers', 'men',
    ARRAY['S','M','L','XL'],
    'https://i.imgur.com/ZuwUZkF.png',
    8, 4.7, false, false, true
  ),
  (
    'AceFit Women''s Sculpt Leggings',
    'High-waist sculpting leggings with compression fit and sweat-wicking technology. Fully squat-proof with phone pocket.',
    12500, 16000, 'leggings', 'women',
    ARRAY['XS','S','M','L','XL'],
    'https://i.imgur.com/ZuwUZkF.png',
    20, 5.0, true, false, true
  ),
  (
    'AceFit Flex Hoodie',
    'Premium cotton-blend hoodie with kangaroo pocket and ribbed cuffs. Great for pre and post workout sessions.',
    18000, NULL, 'hoodies', 'unisex',
    ARRAY['S','M','L','XL','XXL'],
    'https://i.imgur.com/YmQ8fjQ.png',
    12, 4.8, false, true, true
  ),
  (
    'AceFit Sports Bra Pro',
    'High-impact sports bra with maximum support and moisture-wicking lining. Built for all workout types including running and HIIT.',
    7500, NULL, 'sports-bra', 'women',
    ARRAY['XS','S','M','L','XL'],
    'https://i.imgur.com/ZuwUZkF.png',
    25, 4.8, false, false, true
  ),
  (
    'AceFit Gym Shorts',
    '4-way stretch shorts for full range of motion. Lightweight fabric with built-in compression liner and back pocket.',
    9000, 11000, 'shorts', 'men',
    ARRAY['S','M','L','XL','XXL'],
    'https://i.imgur.com/YmQ8fjQ.png',
    0, 4.6, false, false, true
  ),
  (
    'AceFit Tank Top',
    'Ultra-breathable mesh-panel tank top for maximum airflow during high-intensity sessions. Dropped armholes for freedom of movement.',
    6500, NULL, 'tank-tops', 'unisex',
    ARRAY['S','M','L','XL'],
    'https://i.imgur.com/YmQ8fjQ.png',
    30, 4.5, false, false, true
  ),
  (
    'AceFit Tracksuit Set',
    'Complete 2-piece training set for the serious athlete. Premium stretch fabric with tapered fit. Jacket + jogger combo.',
    28000, 35000, 'tracksuits', 'men',
    ARRAY['S','M','L','XL','XXL'],
    'https://i.imgur.com/ZuwUZkF.png',
    6, 4.9, false, true, true
  ),
  (
    'AceFit Women''s Tracksuit',
    'Sleek women''s 2-piece training set in premium stretch fabric. Cropped zip jacket + matching jogger bottoms.',
    26000, NULL, 'tracksuits', 'women',
    ARRAY['XS','S','M','L','XL'],
    'https://i.imgur.com/ZuwUZkF.png',
    10, 4.8, true, false, true
  ),
  (
    'AceFit Performance Hoodie (Women)',
    'Cozy yet athletic women''s hoodie with kangaroo pocket. Tapered fit that looks great on or off the gym floor.',
    16500, NULL, 'hoodies', 'women',
    ARRAY['XS','S','M','L','XL'],
    'https://i.imgur.com/YmQ8fjQ.png',
    9, 4.9, false, true, true
  )
ON CONFLICT DO NOTHING;

-- ============================================================
-- DONE! ✅
-- ============================================================
-- Summary of tables created:
--   ✓ profiles          – user accounts (auto-created on signup)
--   ✓ products          – store inventory
--   ✓ orders            – orders with full delivery + tracking + payment
--   ✓ support_tickets   – customer support
--   ✓ feedback          – product/store reviews
--   ✓ wishlists         – user saved items
--   ✓ email_logs        – email notification history
--
-- Triggers:
--   ✓ handle_new_user            – auto-creates profile on signup
--   ✓ log_order_status_change    – records status history on every update
--   ✓ order_delivered_update_profile – updates customer lifetime value
--
-- Next steps:
--   1. Go to Authentication → Email → Enable "Email OTP"
--   2. Create admin user: Acefitandgainz@gmail.com / AceFit@Admin2025!
--   3. Create storage bucket: product-images (public)
--   4. Deploy edge function: supabase functions deploy send-email
--   5. Set secret: supabase secrets set RESEND_API_KEY=re_xxx
-- ============================================================
