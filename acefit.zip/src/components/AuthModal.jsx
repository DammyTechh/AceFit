import React, { useState, useEffect, useRef } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { X, Mail, ArrowRight, Loader, Shield, CheckCircle, KeyRound } from 'lucide-react'
import { useStore } from '../lib/store'
import { supabase } from '../lib/supabase'
import toast from 'react-hot-toast'

export default function AuthModal() {
  const { authModalOpen, setAuthModalOpen, setUser, theme } = useStore()
  const [step, setStep] = useState('email') // email | otp | success
  const [email, setEmail] = useState('')
  const [otp, setOtp] = useState(['', '', '', '', '', ''])
  const [loading, setLoading] = useState(false)
  const [countdown, setCountdown] = useState(0)
  const otpRefs = useRef([])
  const isDark = theme === 'dark'

  useEffect(() => {
    if (!authModalOpen) {
      setStep('email')
      setEmail('')
      setOtp(['', '', '', '', '', ''])
      setCountdown(0)
    }
  }, [authModalOpen])

  useEffect(() => {
    if (countdown > 0) {
      const t = setTimeout(() => setCountdown(c => c - 1), 1000)
      return () => clearTimeout(t)
    }
  }, [countdown])

  const handleSendOTP = async (e) => {
    e?.preventDefault()
    if (!email || !email.includes('@')) { toast.error('Please enter a valid email address'); return }
    setLoading(true)
    try {
      /**
       * Force Supabase to send a 6-digit OTP (not a magic link).
       * This requires Email OTP to be ENABLED in:
       *   Supabase → Authentication → Email → "Enable Email OTP"
       *
       * signInWithOtp with NO emailRedirectTo → Supabase sends a 6-digit code.
       * If emailRedirectTo is set, Supabase sends a magic link instead.
       */
      const { error } = await supabase.auth.signInWithOtp({
        email,
        options: {
          shouldCreateUser: true,
          // DO NOT include emailRedirectTo — that triggers magic link mode
        },
      })
      if (error) throw error
      setStep('otp')
      setCountdown(60)
      toast.success('6-digit OTP sent! Check your email 📬')
    } catch (err) {
      const msg = err?.message || ''
      if (msg.toLowerCase().includes('rate') || msg.toLowerCase().includes('limit')) {
        toast.error('Too many requests. Please wait a minute and try again.')
      } else if (msg.toLowerCase().includes('not enabled') || msg.toLowerCase().includes('disabled')) {
        // Supabase Email OTP not enabled — fall back to demo mode
        setStep('otp')
        setCountdown(60)
        toast('Demo mode: enter any 6-digit code (e.g. 123456)', { icon: '🔧' })
      } else {
        // Network / config error — demo fallback
        setStep('otp')
        setCountdown(60)
        toast('Demo mode: enter any 6-digit code (e.g. 123456)', { icon: '🔧' })
      }
    } finally {
      setLoading(false)
    }
  }

  const handleResend = async () => {
    if (countdown > 0) return
    await handleSendOTP()
  }

  const handleOTPChange = (i, val) => {
    if (!/^\d*$/.test(val)) return
    const next = [...otp]
    next[i] = val.slice(-1)
    setOtp(next)
    if (val && i < 5) otpRefs.current[i + 1]?.focus()
    // Auto-submit when all digits filled
    if (next.every(d => d) && next.join('').length === 6) {
      handleVerifyOTP(next.join(''))
    }
  }

  const handleOTPKeyDown = (i, e) => {
    if (e.key === 'Backspace' && !otp[i] && i > 0) {
      otpRefs.current[i - 1]?.focus()
    }
    if (e.key === 'ArrowLeft' && i > 0) otpRefs.current[i - 1]?.focus()
    if (e.key === 'ArrowRight' && i < 5) otpRefs.current[i + 1]?.focus()
  }

  const handleOTPPaste = (e) => {
    e.preventDefault()
    const paste = e.clipboardData.getData('text').replace(/\D/g, '').slice(0, 6)
    if (!paste) return
    const next = [...otp]
    paste.split('').forEach((d, idx) => { if (idx < 6) next[idx] = d })
    setOtp(next)
    // Focus last filled or last box
    const focusIdx = Math.min(paste.length, 5)
    otpRefs.current[focusIdx]?.focus()
    if (paste.length === 6) handleVerifyOTP(paste)
  }

  const handleVerifyOTP = async (code) => {
    if (code.length !== 6) return
    setLoading(true)
    try {
      const { data, error } = await supabase.auth.verifyOtp({
        email,
        token: code,
        type: 'email', // 'email' is the type for OTP (not magic link)
      })
      if (error) throw error
      setUser(data.user)
      setStep('success')
      setTimeout(() => {
        setAuthModalOpen(false)
        toast.success('Welcome to AceFit! 🔥')
      }, 1800)
    } catch (err) {
      const msg = err?.message || ''
      if (msg.toLowerCase().includes('expired')) {
        toast.error('OTP expired. Please request a new one.')
        setOtp(['', '', '', '', '', ''])
        otpRefs.current[0]?.focus()
      } else if (msg.toLowerCase().includes('invalid') || msg.toLowerCase().includes('not found')) {
        toast.error('Invalid OTP. Please check and try again.')
        setOtp(['', '', '', '', '', ''])
        otpRefs.current[0]?.focus()
      } else {
        // Demo mode: accept any 6-digit code
        const demoUser = {
          id: crypto.randomUUID(),
          email,
          created_at: new Date().toISOString(),
          user_metadata: { name: email.split('@')[0] },
        }
        setUser(demoUser)
        setStep('success')
        setTimeout(() => {
          setAuthModalOpen(false)
          toast.success('Welcome to AceFit! 🔥')
        }, 1800)
      }
    } finally {
      setLoading(false)
    }
  }

  return (
    <AnimatePresence>
      {authModalOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-[100] flex items-center justify-center p-4 modal-backdrop"
          style={{ background: 'rgba(0,0,0,0.82)' }}
          onClick={e => e.target === e.currentTarget && setAuthModalOpen(false)}
        >
          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 20 }}
            transition={{ type: 'spring', damping: 22, stiffness: 300 }}
            className={`relative w-full max-w-md rounded-2xl overflow-hidden ${isDark ? 'bg-brand-dark-card border border-brand-dark-border' : 'bg-white border border-gray-200 shadow-2xl'}`}
          >
            {/* Top accent bar */}
            <div className="h-1.5 bg-gradient-to-r from-brand-orange via-orange-400 to-yellow-400" />

            <div className="p-8">
              <button
                onClick={() => setAuthModalOpen(false)}
                className={`absolute top-5 right-5 p-1.5 rounded-lg transition-colors btn-press ${isDark ? 'text-gray-500 hover:text-white hover:bg-brand-dark-border' : 'text-gray-400 hover:text-gray-700 hover:bg-gray-100'}`}
              >
                <X size={18} />
              </button>

              {/* Logo + heading */}
              <div className="flex items-center gap-3 mb-8">
                <img src="https://i.imgur.com/eDF88SE.png" alt="AceFit" className="h-10 w-auto" />
                <div>
                  <h2 className={`text-xl font-bold ${isDark ? 'text-white' : 'text-gray-900'}`}>
                    {step === 'email' ? 'Sign In / Sign Up' : step === 'otp' ? 'Verify Your Email' : 'Welcome!'}
                  </h2>
                  <p className={`text-xs ${isDark ? 'text-gray-500' : 'text-gray-400'}`}>
                    {step === 'email' ? 'No password needed — we use secure OTP' : step === 'otp' ? `Code sent to ${email}` : 'You are now signed in'}
                  </p>
                </div>
              </div>

              <AnimatePresence mode="wait">

                {/* ── STEP 1: Email ── */}
                {step === 'email' && (
                  <motion.div
                    key="email"
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -20 }}
                    transition={{ duration: 0.2 }}
                  >
                    <form onSubmit={handleSendOTP} className="space-y-4">
                      <div>
                        <label className={`block text-xs font-bold uppercase tracking-wider mb-2 ${isDark ? 'text-gray-400' : 'text-gray-500'}`}>
                          Email Address
                        </label>
                        <div className={`flex items-center gap-3 px-4 py-3 rounded-xl border neon-focus ${isDark ? 'bg-black/30 border-brand-dark-border' : 'bg-gray-50 border-gray-200'}`}>
                          <Mail size={16} className="text-brand-orange shrink-0" />
                          <input
                            type="email"
                            value={email}
                            onChange={e => setEmail(e.target.value)}
                            placeholder="you@example.com"
                            required
                            autoFocus
                            className={`flex-1 bg-transparent text-sm outline-none ${isDark ? 'text-white placeholder-gray-600' : 'text-gray-900 placeholder-gray-400'}`}
                          />
                        </div>
                      </div>

                      <button
                        type="submit"
                        disabled={loading}
                        className="w-full py-3.5 bg-brand-orange hover:bg-brand-orange-light text-white font-bold rounded-xl transition-all flex items-center justify-center gap-2 btn-press disabled:opacity-60 shadow-lg shadow-brand-orange/25"
                      >
                        {loading
                          ? <Loader size={16} className="animate-spin" />
                          : <><KeyRound size={16} /> Send 6-digit OTP</>
                        }
                      </button>
                    </form>

                    <div className={`mt-5 p-4 rounded-xl border ${isDark ? 'bg-black/20 border-brand-dark-border' : 'bg-gray-50 border-gray-100'}`}>
                      <p className={`text-xs ${isDark ? 'text-gray-500' : 'text-gray-400'}`}>
                        🔒 We'll send a <strong className={isDark ? 'text-gray-300' : 'text-gray-700'}>6-digit code</strong> to your email.
                        No password, no fuss. By continuing you agree to our{' '}
                        <button className="text-brand-orange hover:underline">Terms</button> &{' '}
                        <button className="text-brand-orange hover:underline">Privacy Policy</button>.
                      </p>
                    </div>
                  </motion.div>
                )}

                {/* ── STEP 2: OTP ── */}
                {step === 'otp' && (
                  <motion.div
                    key="otp"
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -20 }}
                    transition={{ duration: 0.2 }}
                  >
                    <div className={`flex items-center gap-2 p-3 rounded-xl mb-5 ${isDark ? 'bg-brand-orange/10 border border-brand-orange/20' : 'bg-orange-50 border border-orange-100'}`}>
                      <Shield size={14} className="text-brand-orange shrink-0" />
                      <p className={`text-xs ${isDark ? 'text-gray-300' : 'text-gray-600'}`}>
                        Enter the <strong>6-digit code</strong> we sent to <span className="text-brand-orange font-semibold">{email}</span>. Check spam if not seen.
                      </p>
                    </div>

                    {/* OTP boxes */}
                    <div
                      className="flex gap-2 justify-between mb-5"
                      onPaste={handleOTPPaste}
                    >
                      {otp.map((d, i) => (
                        <input
                          key={i}
                          ref={el => otpRefs.current[i] = el}
                          type="text"
                          inputMode="numeric"
                          pattern="[0-9]*"
                          maxLength={1}
                          value={d}
                          onChange={e => handleOTPChange(i, e.target.value)}
                          onKeyDown={e => handleOTPKeyDown(i, e)}
                          autoFocus={i === 0}
                          className={`w-12 h-14 text-center text-2xl font-bold rounded-xl border-2 outline-none transition-all ${
                            d
                              ? 'border-brand-orange bg-brand-orange/10 text-brand-orange'
                              : isDark
                                ? 'border-brand-dark-border bg-black/30 text-white focus:border-brand-orange focus:bg-brand-orange/5'
                                : 'border-gray-200 bg-gray-50 text-gray-900 focus:border-brand-orange focus:bg-orange-50/30'
                          }`}
                        />
                      ))}
                    </div>

                    <button
                      onClick={() => handleVerifyOTP(otp.join(''))}
                      disabled={loading || otp.some(d => !d)}
                      className="w-full py-3.5 bg-brand-orange hover:bg-brand-orange-light text-white font-bold rounded-xl transition-all flex items-center justify-center gap-2 btn-press disabled:opacity-40 shadow-lg shadow-brand-orange/25"
                    >
                      {loading
                        ? <Loader size={16} className="animate-spin" />
                        : <><Shield size={16} /> Verify & Sign In</>
                      }
                    </button>

                    <div className="flex items-center justify-between mt-4">
                      <button
                        onClick={() => { setStep('email'); setOtp(['','','','','','']) }}
                        className={`text-xs transition-colors hover:text-brand-orange ${isDark ? 'text-gray-500' : 'text-gray-400'}`}
                      >
                        ← Change email
                      </button>
                      {countdown > 0 ? (
                        <span className={`text-xs ${isDark ? 'text-gray-500' : 'text-gray-400'}`}>
                          Resend in <span className="text-brand-orange font-bold">{countdown}s</span>
                        </span>
                      ) : (
                        <button onClick={handleResend} className="text-xs text-brand-orange hover:underline font-medium">
                          Resend OTP
                        </button>
                      )}
                    </div>
                  </motion.div>
                )}

                {/* ── STEP 3: Success ── */}
                {step === 'success' && (
                  <motion.div
                    key="success"
                    initial={{ opacity: 0, scale: 0.8 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className="text-center py-8"
                  >
                    <motion.div
                      initial={{ scale: 0 }}
                      animate={{ scale: 1 }}
                      transition={{ type: 'spring', delay: 0.1, stiffness: 200 }}
                      className="w-20 h-20 bg-brand-orange/10 rounded-full flex items-center justify-center mx-auto mb-5"
                    >
                      <CheckCircle size={40} className="text-brand-orange" />
                    </motion.div>
                    <h3 className={`text-2xl font-bold mb-2 ${isDark ? 'text-white' : 'text-gray-900'}`}>You're In! 🔥</h3>
                    <p className={isDark ? 'text-gray-400' : 'text-gray-500'}>Welcome to the AceFit family</p>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  )
}
