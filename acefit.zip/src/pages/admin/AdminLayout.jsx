import React, { useState, useEffect } from 'react'
import { Outlet, NavLink, useNavigate } from 'react-router-dom'
import { motion, AnimatePresence } from 'framer-motion'
import {
  LayoutDashboard, Package, ShoppingCart, MessageSquare,
  Users, Star, Settings, Menu, X, LogOut, Sun, Moon,
  ChevronRight, Bell, Shield
} from 'lucide-react'
import { useStore } from '../../lib/store'
import { supabase } from '../../lib/supabase'
import toast from 'react-hot-toast'

const NAV_ITEMS = [
  { path: '/admin', icon: LayoutDashboard, label: 'Dashboard', end: true },
  { path: '/admin/products', icon: Package, label: 'Products' },
  { path: '/admin/orders', icon: ShoppingCart, label: 'Orders' },
  { path: '/admin/tickets', icon: MessageSquare, label: 'Support Tickets' },
  { path: '/admin/customers', icon: Users, label: 'Customers' },
  { path: '/admin/feedback', icon: Star, label: 'Feedback' },
  { path: '/admin/settings', icon: Settings, label: 'Settings' },
]

const ADMIN_EMAIL = 'Acefitandgainz@gmail.com'

export default function AdminLayout() {
  const { theme, toggleTheme } = useStore()
  const [sidebarOpen, setSidebarOpen] = useState(true)
  const [authenticated, setAuthenticated] = useState(false)
  const [adminEmail, setAdminEmail] = useState('')
  const [adminPass, setAdminPass] = useState('')
  const [authLoading, setAuthLoading] = useState(false)
  const navigate = useNavigate()
  const isDark = theme === 'dark'

  // Simple admin auth check from session
  useEffect(() => {
    const adminAuth = sessionStorage.getItem('acefit_admin')
    if (adminAuth === 'true') setAuthenticated(true)
  }, [])

  const handleAdminLogin = async (e) => {
    e.preventDefault()
    setAuthLoading(true)
    try {
      // Allow demo access or real Supabase admin check
      if (adminEmail === ADMIN_EMAIL || adminEmail === 'admin@acefit.com') {
        sessionStorage.setItem('acefit_admin', 'true')
        setAuthenticated(true)
        toast.success('Welcome, Admin! 🔥')
      } else {
        // Try Supabase auth
        const { data, error } = await supabase.auth.signInWithPassword({ email: adminEmail, password: adminPass })
        if (error) throw error
        sessionStorage.setItem('acefit_admin', 'true')
        setAuthenticated(true)
        toast.success('Welcome, Admin!')
      }
    } catch {
      toast.error('Invalid admin credentials')
    } finally {
      setAuthLoading(false)
    }
  }

  const handleLogout = () => {
    sessionStorage.removeItem('acefit_admin')
    setAuthenticated(false)
    toast.success('Logged out')
  }

  if (!authenticated) {
    return (
      <div className={`min-h-screen flex items-center justify-center p-4 ${isDark ? 'bg-brand-black' : 'bg-gray-50'}`}>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className={`w-full max-w-sm rounded-2xl p-8 border ${isDark ? 'bg-brand-dark-card border-brand-dark-border' : 'bg-white border-gray-200 shadow-lg'}`}
        >
          <div className="h-1.5 bg-gradient-to-r from-brand-orange to-yellow-400 rounded-full mb-8 -mx-8 -mt-8" />
          <div className="flex items-center gap-3 mb-8">
            <div className="w-10 h-10 bg-brand-orange/10 rounded-xl flex items-center justify-center">
              <Shield size={20} className="text-brand-orange" />
            </div>
            <div>
              <h2 className={`font-bold text-lg ${isDark ? 'text-white' : 'text-gray-900'}`}>Admin Panel</h2>
              <p className={`text-xs ${isDark ? 'text-gray-500' : 'text-gray-400'}`}>AceFit Management</p>
            </div>
          </div>
          <form onSubmit={handleAdminLogin} className="space-y-4">
            <input
              type="email"
              placeholder="Admin Email"
              value={adminEmail}
              onChange={e => setAdminEmail(e.target.value)}
              required
              className={`w-full px-4 py-3 rounded-xl border text-sm outline-none neon-focus ${isDark ? 'bg-black/30 border-brand-dark-border text-white placeholder-gray-600' : 'bg-gray-50 border-gray-200 text-gray-900 placeholder-gray-400'}`}
            />
            <input
              type="password"
              placeholder="Password (optional for demo)"
              value={adminPass}
              onChange={e => setAdminPass(e.target.value)}
              className={`w-full px-4 py-3 rounded-xl border text-sm outline-none neon-focus ${isDark ? 'bg-black/30 border-brand-dark-border text-white placeholder-gray-600' : 'bg-gray-50 border-gray-200 text-gray-900 placeholder-gray-400'}`}
            />
            <div className={`p-3 rounded-xl border text-xs space-y-1 ${isDark ? 'border-brand-orange/20 bg-brand-orange/5' : 'border-orange-100 bg-orange-50'}`}>
              <p className="text-brand-orange font-bold">Admin Credentials</p>
              <p className={isDark ? 'text-gray-400' : 'text-gray-600'}>
                📧 <span className="font-mono">Acefitandgainz@gmail.com</span>
              </p>
              <p className={isDark ? 'text-gray-400' : 'text-gray-600'}>
                🔑 <span className="font-mono">AceFit@Admin2025!</span>
              </p>
              <p className={`text-[10px] mt-1 ${isDark ? 'text-gray-600' : 'text-gray-400'}`}>
                Demo mode: email only (no password needed)
              </p>
            </div>
            <button
              type="submit"
              disabled={authLoading}
              className="w-full py-3.5 bg-brand-orange hover:bg-brand-orange-light text-white font-bold rounded-xl transition-all btn-press shadow-lg shadow-brand-orange/25 disabled:opacity-60"
            >
              {authLoading ? 'Signing in...' : 'Access Admin Panel'}
            </button>
          </form>
        </motion.div>
      </div>
    )
  }

  return (
    <div className={`flex min-h-screen ${isDark ? 'bg-brand-black' : 'bg-gray-50'}`}>
      {/* Sidebar */}
      <AnimatePresence>
        {sidebarOpen && (
          <motion.aside
            initial={{ x: -280 }}
            animate={{ x: 0 }}
            exit={{ x: -280 }}
            transition={{ type: 'spring', damping: 25, stiffness: 300 }}
            className={`fixed left-0 top-0 bottom-0 w-64 z-40 flex flex-col border-r ${isDark ? 'bg-[#0D0D0D] border-brand-dark-border' : 'bg-white border-gray-200'}`}
          >
            {/* Logo */}
            <div className={`p-5 border-b ${isDark ? 'border-brand-dark-border' : 'border-gray-100'}`}>
              <div className="flex items-center gap-3">
                <img src="https://i.imgur.com/eDF88SE.png" alt="AceFit" className="h-8 w-auto" />
                <div>
                  <p className={`font-bold text-sm ${isDark ? 'text-white' : 'text-gray-900'}`}>AceFit Admin</p>
                  <p className={`text-[10px] ${isDark ? 'text-gray-600' : 'text-gray-400'}`}>Management Panel</p>
                </div>
              </div>
            </div>

            {/* Nav */}
            <nav className="flex-1 p-4 space-y-1 overflow-y-auto">
              {NAV_ITEMS.map(item => (
                <NavLink
                  key={item.path}
                  to={item.path}
                  end={item.end}
                  className={({ isActive }) =>
                    `flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all group ${
                      isActive
                        ? 'bg-brand-orange/15 text-brand-orange border-l-2 border-brand-orange pl-2'
                        : isDark
                          ? 'text-gray-400 hover:text-white hover:bg-brand-dark-border'
                          : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
                    }`
                  }
                >
                  <item.icon size={18} className="shrink-0" />
                  {item.label}
                  <ChevronRight size={14} className="ml-auto opacity-0 group-hover:opacity-100 transition-opacity" />
                </NavLink>
              ))}
            </nav>

            {/* Footer */}
            <div className={`p-4 border-t ${isDark ? 'border-brand-dark-border' : 'border-gray-100'}`}>
              <div className={`flex items-center gap-3 mb-3 px-3 py-2 rounded-xl ${isDark ? 'bg-brand-dark-border' : 'bg-gray-50'}`}>
                <div className="w-8 h-8 bg-brand-orange rounded-full flex items-center justify-center text-white text-xs font-bold">A</div>
                <div className="flex-1 min-w-0">
                  <p className={`text-xs font-semibold truncate ${isDark ? 'text-white' : 'text-gray-900'}`}>AceFit Admin</p>
                  <p className={`text-[10px] truncate ${isDark ? 'text-gray-500' : 'text-gray-400'}`}>{ADMIN_EMAIL}</p>
                </div>
              </div>
              <button
                onClick={handleLogout}
                className={`w-full flex items-center gap-2 px-3 py-2 rounded-xl text-sm transition-colors ${isDark ? 'text-gray-500 hover:text-red-400 hover:bg-red-400/10' : 'text-gray-500 hover:text-red-500 hover:bg-red-50'}`}
              >
                <LogOut size={15} /> Sign Out
              </button>
            </div>
          </motion.aside>
        )}
      </AnimatePresence>

      {/* Main */}
      <div className={`flex-1 flex flex-col transition-all duration-300 ${sidebarOpen ? 'ml-64' : 'ml-0'}`}>
        {/* Top bar */}
        <header className={`sticky top-0 z-30 flex items-center justify-between px-6 h-14 border-b ${isDark ? 'bg-brand-black/95 border-brand-dark-border' : 'bg-white/95 border-gray-200'} glass`}>
          <button
            onClick={() => setSidebarOpen(s => !s)}
            className={`p-2 rounded-lg transition-colors btn-press ${isDark ? 'text-gray-400 hover:text-white hover:bg-brand-dark-border' : 'text-gray-500 hover:text-gray-900 hover:bg-gray-100'}`}
          >
            {sidebarOpen ? <X size={18} /> : <Menu size={18} />}
          </button>

          <div className="flex items-center gap-2">
            <button
              onClick={toggleTheme}
              className={`p-2 rounded-lg transition-colors btn-press ${isDark ? 'text-gray-400 hover:text-white hover:bg-brand-dark-border' : 'text-gray-500 hover:text-gray-900 hover:bg-gray-100'}`}
            >
              {isDark ? <Sun size={16} /> : <Moon size={16} />}
            </button>
            <button className={`p-2 rounded-lg transition-colors btn-press relative ${isDark ? 'text-gray-400 hover:text-white hover:bg-brand-dark-border' : 'text-gray-500 hover:text-gray-900 hover:bg-gray-100'}`}>
              <Bell size={16} />
              <span className="absolute top-1.5 right-1.5 w-1.5 h-1.5 bg-brand-orange rounded-full" />
            </button>
            <div className="w-8 h-8 bg-brand-orange rounded-full flex items-center justify-center text-white text-xs font-bold cursor-pointer">A</div>
          </div>
        </header>

        {/* Page content */}
        <main className="flex-1 p-6 overflow-y-auto">
          <Outlet />
        </main>
      </div>
    </div>
  )
}
