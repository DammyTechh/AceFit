import React, { useEffect, useState } from 'react'
import { motion } from 'framer-motion'
import { TrendingUp, ShoppingCart, Users, Package, Star, MessageSquare, ArrowUpRight, ArrowDownRight, Eye } from 'lucide-react'
import { supabase } from '../../lib/supabase'
import { useStore } from '../../lib/store'

const DEMO_STATS = {
  revenue: 485000,
  orders: 34,
  customers: 128,
  products: 12,
  tickets: 3,
  avgRating: 4.8,
  revenueChange: 12.5,
  ordersChange: 8.3,
  customersChange: 15.2,
}

const RECENT_ORDERS = [
  { id: 'ORD-001', customer: 'Adaeze Okafor', items: 'AceFit Pro Tee × 2', total: 17000, status: 'delivered', date: '2 hrs ago' },
  { id: 'ORD-002', customer: 'Emeka Nwosu', items: 'Power Joggers × 1', total: 15000, status: 'processing', date: '5 hrs ago' },
  { id: 'ORD-003', customer: 'Fatima Bello', items: 'Sculpt Leggings × 1', total: 12500, status: 'shipped', date: '1 day ago' },
  { id: 'ORD-004', customer: 'Chidi Obi', items: 'Tracksuit Set × 1', total: 28000, status: 'pending', date: '1 day ago' },
  { id: 'ORD-005', customer: 'Ngozi Eze', items: 'Sports Bra + Tank', total: 14000, status: 'delivered', date: '2 days ago' },
]

const STATUS_BADGE = {
  delivered: 'badge-success',
  processing: 'badge-info',
  shipped: 'badge-warning',
  pending: 'badge-warning',
  cancelled: 'badge-danger',
}

export default function AdminDashboard() {
  const { theme } = useStore()
  const [stats, setStats] = useState(DEMO_STATS)
  const [recentOrders, setRecentOrders] = useState(RECENT_ORDERS)
  const isDark = theme === 'dark'

  useEffect(() => {
    loadStats()
  }, [])

  const loadStats = async () => {
    try {
      const [{ count: ordersCount }, { count: customersCount }, { count: productsCount }] = await Promise.all([
        supabase.from('orders').select('*', { count: 'exact', head: true }),
        supabase.from('profiles').select('*', { count: 'exact', head: true }),
        supabase.from('products').select('*', { count: 'exact', head: true }),
      ])

      const { data: orders } = await supabase.from('orders').select('total').eq('status', 'delivered')
      const revenue = orders?.reduce((t, o) => t + (o.total || 0), 0) || 0

      setStats(s => ({
        ...s,
        orders: ordersCount || s.orders,
        customers: customersCount || s.customers,
        products: productsCount || s.products,
        revenue: revenue || s.revenue,
      }))

      const { data: recentOrdersData } = await supabase
        .from('orders')
        .select('*, profiles(email)')
        .order('created_at', { ascending: false })
        .limit(5)

      if (recentOrdersData?.length) setRecentOrders(recentOrdersData)
    } catch (e) {
      // Use demo data
    }
  }

  const statCards = [
    { label: 'Total Revenue', value: `₦${stats.revenue.toLocaleString()}`, change: stats.revenueChange, icon: TrendingUp, color: 'text-green-400', bg: 'bg-green-400/10' },
    { label: 'Total Orders', value: stats.orders, change: stats.ordersChange, icon: ShoppingCart, color: 'text-blue-400', bg: 'bg-blue-400/10' },
    { label: 'Customers', value: stats.customers, change: stats.customersChange, icon: Users, color: 'text-purple-400', bg: 'bg-purple-400/10' },
    { label: 'Products', value: stats.products, change: null, icon: Package, color: 'text-brand-orange', bg: 'bg-brand-orange/10' },
    { label: 'Open Tickets', value: stats.tickets, change: null, icon: MessageSquare, color: 'text-yellow-400', bg: 'bg-yellow-400/10' },
    { label: 'Avg Rating', value: stats.avgRating, change: null, icon: Star, color: 'text-yellow-400', bg: 'bg-yellow-400/10' },
  ]

  return (
    <div className="space-y-8">
      {/* Header */}
      <div>
        <h1 className={`font-display text-4xl ${isDark ? 'text-white' : 'text-gray-900'}`}>DASHBOARD</h1>
        <p className={`text-sm mt-1 ${isDark ? 'text-gray-500' : 'text-gray-400'}`}>Welcome back! Here's what's happening with AceFit today.</p>
      </div>

      {/* Stats grid */}
      <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-6 gap-4">
        {statCards.map((stat, i) => (
          <motion.div
            key={stat.label}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.08 }}
            className={`p-4 rounded-2xl border ${isDark ? 'bg-brand-dark-card border-brand-dark-border' : 'bg-white border-gray-200'}`}
          >
            <div className={`w-9 h-9 ${stat.bg} rounded-xl flex items-center justify-center mb-3`}>
              <stat.icon size={18} className={stat.color} />
            </div>
            <p className={`text-2xl font-bold ${isDark ? 'text-white' : 'text-gray-900'}`}>{stat.value}</p>
            <p className={`text-xs mt-0.5 ${isDark ? 'text-gray-500' : 'text-gray-400'}`}>{stat.label}</p>
            {stat.change !== null && (
              <div className={`flex items-center gap-0.5 mt-1 text-xs font-medium ${stat.change > 0 ? 'text-green-400' : 'text-red-400'}`}>
                {stat.change > 0 ? <ArrowUpRight size={12} /> : <ArrowDownRight size={12} />}
                {Math.abs(stat.change)}% this week
              </div>
            )}
          </motion.div>
        ))}
      </div>

      {/* Charts row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Revenue mini-chart */}
        <div className={`lg:col-span-2 p-6 rounded-2xl border ${isDark ? 'bg-brand-dark-card border-brand-dark-border' : 'bg-white border-gray-200'}`}>
          <div className="flex items-center justify-between mb-6">
            <div>
              <h3 className={`font-bold ${isDark ? 'text-white' : 'text-gray-900'}`}>Revenue Overview</h3>
              <p className={`text-xs ${isDark ? 'text-gray-500' : 'text-gray-400'}`}>Last 7 days</p>
            </div>
            <span className="badge-success px-3 py-1 rounded-full text-xs font-medium">+12.5%</span>
          </div>
          {/* Simple bar chart */}
          <div className="flex items-end gap-2 h-32">
            {[40, 65, 45, 80, 55, 90, 70].map((h, i) => (
              <motion.div
                key={i}
                initial={{ height: 0 }}
                animate={{ height: `${h}%` }}
                transition={{ delay: i * 0.08, duration: 0.6, ease: 'easeOut' }}
                className={`flex-1 rounded-t-lg ${i === 5 ? 'bg-brand-orange' : isDark ? 'bg-brand-dark-border' : 'bg-gray-200'}`}
              />
            ))}
          </div>
          <div className="flex justify-between mt-2">
            {['Mon','Tue','Wed','Thu','Fri','Sat','Sun'].map(d => (
              <span key={d} className={`text-[10px] ${isDark ? 'text-gray-600' : 'text-gray-400'}`}>{d}</span>
            ))}
          </div>
        </div>

        {/* Order status */}
        <div className={`p-6 rounded-2xl border ${isDark ? 'bg-brand-dark-card border-brand-dark-border' : 'bg-white border-gray-200'}`}>
          <h3 className={`font-bold mb-5 ${isDark ? 'text-white' : 'text-gray-900'}`}>Order Status</h3>
          <div className="space-y-3">
            {[
              { label: 'Delivered', count: 18, pct: 53, color: 'bg-green-400' },
              { label: 'Processing', count: 8, pct: 23, color: 'bg-blue-400' },
              { label: 'Shipped', count: 5, pct: 15, color: 'bg-yellow-400' },
              { label: 'Pending', count: 3, pct: 9, color: 'bg-brand-orange' },
            ].map(s => (
              <div key={s.label}>
                <div className="flex justify-between text-xs mb-1">
                  <span className={isDark ? 'text-gray-400' : 'text-gray-600'}>{s.label}</span>
                  <span className={`font-semibold ${isDark ? 'text-white' : 'text-gray-900'}`}>{s.count}</span>
                </div>
                <div className={`h-1.5 rounded-full ${isDark ? 'bg-brand-dark-border' : 'bg-gray-100'}`}>
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${s.pct}%` }}
                    transition={{ duration: 0.8, delay: 0.3 }}
                    className={`h-full rounded-full ${s.color}`}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Recent orders */}
      <div className={`rounded-2xl border overflow-hidden ${isDark ? 'bg-brand-dark-card border-brand-dark-border' : 'bg-white border-gray-200'}`}>
        <div className={`flex items-center justify-between p-5 border-b ${isDark ? 'border-brand-dark-border' : 'border-gray-100'}`}>
          <h3 className={`font-bold ${isDark ? 'text-white' : 'text-gray-900'}`}>Recent Orders</h3>
          <a href="/admin/orders" className="text-brand-orange text-sm hover:underline flex items-center gap-1">
            View all <ArrowUpRight size={14} />
          </a>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className={`text-xs uppercase tracking-wider ${isDark ? 'bg-black/30 text-gray-500' : 'bg-gray-50 text-gray-400'}`}>
                <th className="px-5 py-3 text-left">Order</th>
                <th className="px-5 py-3 text-left">Customer</th>
                <th className="px-5 py-3 text-left hidden md:table-cell">Items</th>
                <th className="px-5 py-3 text-right">Total</th>
                <th className="px-5 py-3 text-center">Status</th>
                <th className="px-5 py-3 text-right hidden md:table-cell">Date</th>
              </tr>
            </thead>
            <tbody>
              {recentOrders.map((order, i) => (
                <motion.tr
                  key={order.id}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: i * 0.05 }}
                  className={`border-t transition-colors ${isDark ? 'border-brand-dark-border hover:bg-white/2' : 'border-gray-50 hover:bg-gray-50'}`}
                >
                  <td className="px-5 py-4 font-mono text-xs text-brand-orange">{order.id}</td>
                  <td className={`px-5 py-4 font-medium ${isDark ? 'text-white' : 'text-gray-900'}`}>{order.customer}</td>
                  <td className={`px-5 py-4 hidden md:table-cell ${isDark ? 'text-gray-400' : 'text-gray-500'}`}>{order.items}</td>
                  <td className={`px-5 py-4 text-right font-bold ${isDark ? 'text-white' : 'text-gray-900'}`}>₦{Number(order.total).toLocaleString()}</td>
                  <td className="px-5 py-4 text-center">
                    <span className={`px-2.5 py-1 rounded-full text-xs font-medium capitalize ${STATUS_BADGE[order.status] || 'badge-info'}`}>
                      {order.status}
                    </span>
                  </td>
                  <td className={`px-5 py-4 text-right text-xs hidden md:table-cell ${isDark ? 'text-gray-500' : 'text-gray-400'}`}>{order.date}</td>
                </motion.tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
